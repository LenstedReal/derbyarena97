# Wreck Circuit — Grok Mobile Game Prompt

Bu paket, Unity AI tanıtım videosundaki arena araç savaşı türünü Android öncelikli, özgün bir 3D oyuna dönüştürmek için Grok'a verilecek kapsamlı ana talimatı içerir.

## Önerilen yol
- Godot 4.7.2 Stable
- GDScript 2.0
- Android öncelikli 3D / Mobile renderer
- Önce 1 arena + 1 oyuncu aracı + 1 AI rakip + 1 silahla oynanabilir MVP
- Debug APK ve daha sonra signing secrets ile release AAB
- Unity AI paneli veya masaüstü Unity zorunlu değil

Grok'a referans videoyu ve `WreckCircuit_Grok_MobileGame_MasterPrompt_TR.md` dosyasını yükle. İlk cevapta sadece plan üretmesini iste; planı onayladıktan sonra projeyi üretme aşamasına geç.
